"use client";

import { useState } from "react";
import { formatEventDate } from "@/lib/format";

interface Props {
  eventName: string;
  eventDate?: string | null;
  eventCode: string;
  tab: "all" | "favourites";
  onTabChange: (tab: "all" | "favourites") => void;
  totalCount: number;
  favouriteCount: number;
  selectMode: boolean;
  onToggleSelectMode: () => void;
  selectedCount: number;
  selectedIds: string[];
  /** Only the host of a paid event (or staff) may take files out. */
  canDownload: boolean;
}

export function GalleryToolbar({
  eventName,
  eventDate = null,
  eventCode,
  tab,
  onTabChange,
  totalCount,
  favouriteCount,
  selectMode,
  onToggleSelectMode,
  selectedCount,
  selectedIds,
  canDownload,
}: Props) {
  const [downloading, setDownloading] = useState(false);
  const formattedDate = formatEventDate(eventDate);

  async function handleDownload(scope: "all" | "favourites" | "selected") {
    setDownloading(true);
    try {
      const res = await fetch("/api/download/zip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventCode,
          scope,
          photoIds: scope === "selected" ? selectedIds : undefined,
        }),
      });
      if (!res.ok) throw new Error("Download failed");

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${eventCode}-${scope}.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      alert("Download failed. Please try again.");
    } finally {
      setDownloading(false);
    }
  }

  return (
    <div className="sticky top-0 z-10 bg-ink-950/90 backdrop-blur-md border-b border-white/10 px-4 py-3 mb-3">
      <div className="flex items-start justify-between mb-3">
        <div className="min-w-0">
          <h1 className="font-display text-xl truncate">{eventName}</h1>
          {formattedDate && <p className="truncate text-xs text-white/40">{formattedDate}</p>}
        </div>
        <button
          onClick={onToggleSelectMode}
          className="text-sm text-white/60 border border-white/20 rounded-full px-3 py-1.5 shrink-0"
        >
          {selectMode ? "Cancel" : "Select"}
        </button>
      </div>

      <div className="flex items-center gap-2 text-sm mb-3">
        <button
          onClick={() => onTabChange("all")}
          className={`rounded-full px-3 py-1.5 ${tab === "all" ? "bg-white text-ink-950 font-medium" : "text-white/60"}`}
        >
          All Photos: {totalCount}
        </button>
        <button
          onClick={() => onTabChange("favourites")}
          className={`rounded-full px-3 py-1.5 ${tab === "favourites" ? "bg-white text-ink-950 font-medium" : "text-white/60"}`}
        >
          ❤️ Favourites: {favouriteCount}
        </button>
      </div>

      {/* Download controls only render for a caller who is actually entitled
          — the API re-checks, so hiding them is courtesy, not security. */}
      {canDownload && selectMode && selectedCount > 0 && (
        <button
          onClick={() => handleDownload("selected")}
          disabled={downloading}
          className="tap-target w-full bg-accent text-ink-950 font-semibold rounded-xl px-4 py-2.5 disabled:opacity-60"
        >
          {downloading ? "Preparing…" : `Download ${selectedCount} Selected`}
        </button>
      )}

      {canDownload && !selectMode && (
        <button
          onClick={() => handleDownload(tab === "favourites" ? "favourites" : "all")}
          disabled={downloading}
          className="w-full bg-white/10 border border-white/20 text-sm rounded-xl px-3 py-2 disabled:opacity-60"
        >
          {downloading ? "Preparing…" : tab === "favourites" ? "Download Favourites" : "Download All"}
        </button>
      )}
    </div>
  );
}
