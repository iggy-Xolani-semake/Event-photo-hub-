# EventPhoto Hub — V2 Sprints 1–3

Branch `arena/01a0a9df-event-photo-hub`, four commits on top of `main` (`ebc5b19`):

| commit | what |
| --- | --- |
| `a704673` | Sprint 1 — guest journey: QR landing → gallery → upload (18 files) |
| `6a5ab93` | Sprint 2 — client self-service: signup, own dashboard, owner-scoped events (17 files) |
| `5ed648d` | Sprint 3 — packages, payment, download entitlement (18 files) |
| `6a18ce4` | Make migration 0006 re-runnable + SQL-editor state check (3 files) |

`git diff --shortstat main..HEAD` → **45 files changed, 4489 insertions(+), 247 deletions(-)**.
`main` has not been touched.

---

## The three things that changed how the product behaves

**1. Guests never see a paywall, and never need an account.** Scan → landing
("N photos have already been shared") → gallery → upload. The landing screen
carries no pricing, no features and no sign-in. Uploading is optional-nickname
only.

**2. A client can now sign up and see only their own events.** Site-host admins
still see everything. `src/lib/limits.ts` holds the app-wide ceilings; a client
configures inside them.

**3. Gallery access and download entitlement are now two different questions.**

| | question | decided by |
| --- | --- | --- |
| Gallery access | who may LOOK | `events.visibility` |
| Download entitlement | who may TAKE the originals | `events.download_unlocked_at` |

Before this, both download routes gated on visibility alone — any guest holding
a shared event link could download every original.

---

## Do these three things

1. **Run `supabase/migrations/0005_client_self_service.sql`, then `0006_packages_payments.sql`**
   in the Supabase SQL Editor. 0006 is safe to re-run (every statement is
   guarded). If the editor reports an object already existing, run
   **QUERY 1 only** of `docs/MIGRATION_0006_STATE_CHECK.sql` — one catalog-only
   statement that reports present/MISSING for the 16 objects 0006 creates — and
   paste the result back before re-running.
2. **Set real prices in the `packages` table.** Only the 50-photo tier is priced
   (R50). The other four are `price_cents = NULL`, which the app reads as "not
   for sale yet" and refuses to charge for. A NULL price is never treated as free.
3. **Know that no payment gateway is wired up.** `POST /api/events/{code}/checkout`
   creates a *pending* payment and returns no gateway URL; staff confirm an EFT
   with `POST /api/admin/events/{code}/mark-paid`. A provider was deliberately
   not guessed at — webhook signature verification differs per gateway.

**Deliberate behaviour change:** guests lose bulk download. The gallery is the
free product; the originals are the paid one.

---

## Verification (all of it re-run, none of it inferred)

- `_verification/output_0005_20_assertions.txt` — **20/20**, exit 0. Migration
  0005 on PG 18 (PGlite): client profiles, owner-scoped RLS, anon sees no
  events, limit ranges enforced, ownership immutable.
- `_verification/output_0006_17_assertions.txt` — **17/17**, exit 0. Migration
  0006: an owner cannot unlock their own downloads, cannot swap to a bigger
  tier, cannot raise a limit past their package, cannot insert a payment row,
  cannot call `mark_event_paid()`. Service role can, and a repeat call is
  idempotent.
- `_verification/output_0006_rerun_x3.txt` — **23/23**, exit 0. 0006 applied
  three times in a row with no error, still exactly 5 tiers with 1 priced, and
  all 17 security assertions still pass afterwards.
- `_verification/run.mjs` — the entitlement truth table, **6/6**: admins always,
  owners only once paid, guests never.
- `npx tsc --noEmit` clean, `npx next lint` clean, `npm run build` clean.
- Live check on a running server: an unauthenticated
  `GET /api/photos/{id}/download` returns **403**. The pre-Sprint-3 route would
  have returned a presigned R2 URL for the same call.

Bugs that were found only because these harnesses run the migrations rather
than reading them: the paywall trigger's bypass flag evaluated to NULL instead
of false (three-valued logic), silently disabling every guard; and a signature
check that compared `pg_get_function_identity_arguments()` to `'uuid, text, text'`
when that function renders parameter names too.

---

## Known gaps — nothing here is fixed yet

- **A 1,000-photo package cannot be delivered.** `src/app/api/download/zip/route.ts`
  caps at `MAX_ZIP_PHOTOS = 150`. Needs a background archive job → R2 → signed
  expiring URL.
- **Uploads are not verified.** The claimed size is trusted; real bytes, format,
  decodability and dimensions are never checked.
- **There is no server-side guest quota.** `uploader_identifier` is passed
  through and never counted against. The 10-photo limit is a browser promise.
- **Rate limiting is per-process** (`src/lib/rateLimit.ts` uses a `Map`), so it
  resets on deploy and coordinates nothing across instances.
- **Section 2b of `docs/LIVE_DB_AUDIT.sql` has never been run**, so the live
  drift (events +1 column, photos +3 columns) is still unnamed.
- `DEMO482` is still live and `active`.

---

## What is in this zip

- The full repository at `6a18ce4` (source only — no `node_modules`, no `.git`).
- `_verification/` — the database harnesses, the entitlement test, their
  `package.json`, and the raw outputs quoted above. Re-run with
  `cd _verification && npm i @electric-sql/pglite --no-save && node test_idem.mjs`.
- `docs/` — the guest UX spec, the live-database audit scripts, and the
  migration state check.
