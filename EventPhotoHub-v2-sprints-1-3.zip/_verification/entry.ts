import { decideDownloadEntitlement } from "@/lib/auth/downloadEntitlement";
(globalThis as any).__decide = decideDownloadEntitlement;
