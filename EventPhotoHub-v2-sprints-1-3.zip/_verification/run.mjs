import { createRequire } from "node:module";
const require = createRequire("/home/user/Event-photo-hub-/package.json");
const esbuild = require("esbuild");
const REPO = "/home/user/Event-photo-hub-";

await esbuild.build({
  stdin: { contents: await (await import("node:fs/promises")).readFile("/tmp/unit/entry.ts", "utf8"), resolveDir: REPO, loader: "ts", sourcefile: "entry.ts" },
  bundle: true, format: "esm", platform: "node", outfile: "/tmp/unit/bundle.mjs",
  alias: { "@": `${REPO}/src`, "server-only": "/tmp/unit/empty.mjs" },
  define: { "process.env.NODE_ENV": '"test"' }, logLevel: "error",
});

await import("/tmp/unit/bundle.mjs");
const decide = globalThis.__decide;

const cases = [
  ["admin, unpaid event, not the owner", { unlockedAt: null, callerIsAdmin: true, callerOwnsEvent: false }, true, "admin"],
  ["admin, paid event", { unlockedAt: "2026-09-16T00:00:00Z", callerIsAdmin: true, callerOwnsEvent: false }, true, "admin"],
  ["owner, PAID event", { unlockedAt: "2026-09-16T00:00:00Z", callerIsAdmin: false, callerOwnsEvent: true }, true, "owner_paid"],
  ["owner, UNPAID event", { unlockedAt: null, callerIsAdmin: false, callerOwnsEvent: true }, false, "unpaid_owner"],
  ["guest, shared event", { unlockedAt: "2026-09-16T00:00:00Z", callerIsAdmin: false, callerOwnsEvent: false }, false, "not_owner"],
  ["guest, unpaid event", { unlockedAt: null, callerIsAdmin: false, callerOwnsEvent: false }, false, "not_owner"],
];

let failures = 0;
for (const [name, input, expectedAllowed, expectedReason] of cases) {
  const got = decide(input);
  const ok = got.allowed === expectedAllowed && got.reason === expectedReason;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name} -> allowed=${got.allowed} reason=${got.reason}`);
  if (!ok) failures += 1;
}
console.log(failures === 0 ? "\nALL CHECKS PASSED" : `\n${failures} FAILED`);
process.exit(failures ? 1 : 0);
